<?php
 return array (
  'name' => 'GlobalSite',
  'label' => 'Global',
  '_id' => 'GlobalSite5df6181896002',
  'fields' =>
  array (
    0 =>
    array (
      'name' => 'siteName',
      'label' => 'Site Name',
      'type' => 'text',
      'default' => '',
      'info' => '',
      'group' => '',
      'localize' => false,
      'options' =>
      array (
      ),
      'width' => '1-2',
      'lst' => true,
      'acl' =>
      array (
      ),
      'required' => true,
    ),
    1 =>
    array (
      'name' => 'analytics',
      'label' => 'Analytics tacking ID',
      'type' => 'text',
      'default' => '',
      'info' => 'ex: UA-XXXXXXXX-X',
      'group' => '',
      'localize' => false,
      'options' =>
      array (
      ),
      'width' => '1-2',
      'lst' => true,
      'acl' =>
      array (
      ),
    ),
    2 =>
    array (
      'name' => 'copyright',
      'label' => 'Copyright',
      'type' => 'markdown',
      'default' => '',
      'info' => '',
      'group' => '',
      'localize' => false,
      'options' =>
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' =>
      array (
      ),
    ),
    3 =>
    array (
      'name' => 'metaTitle',
      'label' => 'Meta Title',
      'type' => 'text',
      'default' => '',
      'info' => '',
      'group' => 'metas',
      'localize' => true,
      'options' =>
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' =>
      array (
      ),
      'required' => false,
    ),
    4 =>
    array (
      'name' => 'metaDescription',
      'label' => 'Meta Description',
      'type' => 'textarea',
      'default' => '',
      'info' => '',
      'group' => 'metas',
      'localize' => true,
      'options' =>
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' =>
      array (
      ),
      'required' => false,
    ),
    5 =>
    array (
      'name' => 'metaImage',
      'label' => 'Meta Image',
      'type' => 'asset',
      'default' => '',
      'info' => '',
      'group' => 'metas',
      'localize' => false,
      'options' =>
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' =>
      array (
      ),
    ),
    6 =>
    array (
      'name' => 'metaTags',
      'label' => 'Meta Tags',
      'type' => 'tags',
      'default' => '',
      'info' => '',
      'group' => 'metas',
      'localize' => true,
      'options' =>
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' =>
      array (
      ),
    ),
    7 =>
    array (
      'name' => 'street',
      'label' => 'Street',
      'type' => 'text',
      'default' => '',
      'info' => '',
      'group' => 'Contact',
      'localize' => false,
      'options' =>
      array (
      ),
      'width' => '1-3',
      'lst' => true,
      'acl' =>
      array (
      ),
    ),
    8 =>
    array (
      'name' => 'cp',
      'label' => 'CP',
      'type' => 'text',
      'default' => '',
      'info' => '',
      'group' => 'Contact',
      'localize' => false,
      'options' =>
      array (
      ),
      'width' => '1-3',
      'lst' => true,
      'acl' =>
      array (
      ),
    ),
    9 =>
    array (
      'name' => 'city',
      'label' => 'City',
      'type' => 'text',
      'default' => '',
      'info' => '',
      'group' => 'Contact',
      'localize' => false,
      'options' =>
      array (
      ),
      'width' => '1-3',
      'lst' => true,
      'acl' =>
      array (
      ),
    ),
    10 =>
    array (
      'name' => 'phone',
      'label' => 'Phone',
      'type' => 'text',
      'default' => '',
      'info' => '',
      'group' => 'Contact',
      'localize' => false,
      'options' =>
      array (
      ),
      'width' => '1-2',
      'lst' => true,
      'acl' =>
      array (
      ),
    ),
    11 =>
    array (
      'name' => 'mail',
      'label' => 'Mail',
      'type' => 'text',
      'default' => '',
      'info' => '',
      'group' => 'Contact',
      'localize' => false,
      'options' =>
      array (
      ),
      'width' => '1-2',
      'lst' => true,
      'acl' =>
      array (
      ),
    ),
  ),
  'template' => '',
  'data' => NULL,
  '_created' => 1576409112,
  '_modified' => 1576522450,
  'description' => 'Global site information',
  'acl' =>
  array (
    'public' =>
    array (
      'data' => true,
    ),
  ),
  'icon' => 'items.svg',
  'group' => '',
  'color' => '#8E8271',
);
