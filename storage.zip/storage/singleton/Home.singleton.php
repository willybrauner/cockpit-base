<?php
 return array (
  'name' => 'Home',
  'label' => 'Home',
  '_id' => 'Home5dea86862c622',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'title',
      'label' => 'TItle',
      'type' => 'text',
      'default' => '',
      'info' => '',
      'group' => '',
      'localize' => true,
      'options' => 
      array (
        'slug' => true,
      ),
      'width' => '1-2',
      'lst' => true,
      'acl' => 
      array (
      ),
    ),
    1 => 
    array (
      'name' => 'customSlug',
      'label' => 'Custom Slug',
      'type' => 'text',
      'default' => '',
      'info' => '',
      'group' => '',
      'localize' => true,
      'options' => 
      array (
      ),
      'width' => '1-2',
      'lst' => true,
      'acl' => 
      array (
      ),
    ),
    2 => 
    array (
      'name' => 'cover',
      'label' => 'Cover',
      'type' => 'gallery',
      'default' => '',
      'info' => '',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
    ),
    3 => 
    array (
      'name' => 'description',
      'label' => 'Description',
      'type' => 'markdown',
      'default' => '',
      'info' => '',
      'group' => '',
      'localize' => true,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
    ),
    4 => 
    array (
      'name' => 'gallery',
      'label' => 'Gallery',
      'type' => 'gallery',
      'default' => '',
      'info' => '',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
    ),
    5 => 
    array (
      'name' => 'metaTitle',
      'label' => 'Meta Title',
      'type' => 'text',
      'default' => '',
      'info' => '',
      'group' => 'metas',
      'localize' => true,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
    ),
    6 => 
    array (
      'name' => 'metaDescription',
      'label' => 'Meta Description ',
      'type' => 'text',
      'default' => '',
      'info' => '',
      'group' => 'metas',
      'localize' => true,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
    ),
    7 => 
    array (
      'name' => 'metaImage',
      'label' => 'Meta Image',
      'type' => 'gallery',
      'default' => '',
      'info' => '',
      'group' => 'metas',
      'localize' => false,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
    ),
  ),
  'template' => '',
  'data' => NULL,
  '_created' => 1575650950,
  '_modified' => 1576417028,
  'description' => '',
  'acl' => 
  array (
    'author' => 
    array (
      'data' => true,
      'form' => false,
      'edit' => false,
    ),
    'public' => 
    array (
      'data' => true,
    ),
    'editor' => 
    array (
      'form' => true,
      'data' => true,
    ),
    'publisher' => 
    array (
      'data' => true,
      'form' => true,
    ),
    'Publisher' => 
    array (
      'form' => true,
      'data' => true,
    ),
    'Editor' => 
    array (
      'form' => true,
      'data' => true,
    ),
  ),
  'color' => '#48CFAD',
  'icon' => 'post.svg',
);