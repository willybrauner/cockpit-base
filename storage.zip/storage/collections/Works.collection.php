<?php
 return array (
  'name' => 'Works',
  'label' => 'Works',
  '_id' => 'Works5debc96ec1a53',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'title',
      'label' => 'Title',
      'type' => 'text',
      'default' => '',
      'info' => '',
      'group' => '',
      'localize' => true,
      'options' => 
      array (
        'slug' => true,
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
    ),
    1 => 
    array (
      'name' => 'customSlug',
      'label' => 'Custom slug',
      'type' => 'text',
      'default' => '',
      'info' => '',
      'group' => '',
      'localize' => true,
      'options' => 
      array (
        'type' => 'Text',
        'slug' => true,
      ),
      'width' => '1-3',
      'lst' => true,
      'acl' => 
      array (
      ),
    ),
    2 => 
    array (
      'name' => 'publish',
      'label' => 'Publish ',
      'type' => 'boolean',
      'default' => '',
      'info' => '',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
      ),
      'width' => '1-3',
      'lst' => false,
      'acl' => 
      array (
      ),
    ),
    3 => 
    array (
      'name' => 'category',
      'label' => 'Category',
      'type' => 'collectionlink',
      'default' => '',
      'info' => '',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
        'link' => 'Categories',
        'display' => 'Category',
        'multiple' => false,
        'limit' => 1,
      ),
      'width' => '1-3',
      'lst' => true,
      'acl' => 
      array (
      ),
    ),
    4 => 
    array (
      'name' => 'gallery',
      'label' => 'Gallery',
      'type' => 'gallery',
      'default' => '',
      'info' => '',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
    ),
    5 => 
    array (
      'name' => 'description',
      'label' => 'Description',
      'type' => 'markdown',
      'default' => '',
      'info' => '',
      'group' => '',
      'localize' => true,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
    ),
    6 => 
    array (
      'name' => 'blocks',
      'label' => 'Blocks',
      'type' => 'repeater',
      'default' => '',
      'info' => '',
      'group' => '',
      'localize' => true,
      'options' => 
      array (
        'fields' => 
        array (
          0 => 
          array (
            'type' => 'markdown',
            'label' => 'Text Block',
          ),
          1 => 
          array (
            'type' => 'gallery',
            'label' => 'Image Block',
          ),
          2 => 
          array (
            'type' => 'repeater',
            'label' => 'item',
            'options' => 
            array (
              'fields' => 
              array (
                0 => 
                array (
                  'type' => 'text',
                  'label' => 'Text component',
                ),
              ),
            ),
          ),
        ),
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
    ),
    7 => 
    array (
      'name' => 'metaTitle',
      'label' => 'Meta Title',
      'type' => 'text',
      'default' => '',
      'info' => '',
      'group' => 'metas',
      'localize' => true,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
    ),
    8 => 
    array (
      'name' => 'metaDescription',
      'label' => 'Meta Description',
      'type' => 'text',
      'default' => '',
      'info' => '',
      'group' => 'metas',
      'localize' => true,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
    ),
    9 => 
    array (
      'name' => 'metaImage',
      'label' => 'Meta Image ',
      'type' => 'asset',
      'default' => '',
      'info' => '',
      'group' => 'metas',
      'localize' => false,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
    ),
  ),
  'sortable' => false,
  'in_menu' => false,
  '_created' => 1575733614,
  '_modified' => 1576415894,
  'color' => '#A0D468',
  'acl' => 
  array (
    'author' => 
    array (
      'collection_edit' => false,
      'entries_view' => false,
      'entries_edit' => false,
      'entries_create' => false,
      'entries_delete' => false,
    ),
    '' => 
    array (
      'collection_edit' => false,
    ),
    'public' => 
    array (
      'entries_view' => true,
      'entries_edit' => false,
      'entries_create' => false,
      'entries_delete' => false,
    ),
    'editor' => 
    array (
      'collection_edit' => true,
      'entries_view' => true,
      'entries_edit' => true,
      'entries_create' => true,
      'entries_delete' => true,
    ),
    'Publisher' => 
    array (
      'entries_view' => true,
      'entries_edit' => true,
      'entries_create' => true,
      'entries_delete' => true,
    ),
    'Editor' => 
    array (
      'entries_view' => true,
      'entries_edit' => true,
      'entries_create' => true,
      'entries_delete' => true,
    ),
  ),
  'rules' => 
  array (
    'create' => 
    array (
      'enabled' => false,
    ),
    'read' => 
    array (
      'enabled' => false,
    ),
    'update' => 
    array (
      'enabled' => false,
    ),
    'delete' => 
    array (
      'enabled' => false,
    ),
  ),
  'icon' => 'cart.svg',
  'contentpreview' => 
  array (
    'enabled' => false,
  ),
  'group' => '',
);